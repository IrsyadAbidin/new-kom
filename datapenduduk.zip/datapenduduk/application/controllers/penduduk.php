<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Penduduk extends CI_Controller {

    public function __construct()
	{
		parent::__construct();
		$this->load->library('form_validation');
        $this->load->model('Model_penduduk');
        $this->load->model('Model_bansos');
        if(!$this->session->userdata('username')) {
            redirect('auth');
        }
    }

    public function index()
    {
        $data['title'] = 'penduduk';
        if ($this->input->post('submit')) {
            $data['keyword'] = $this->input->post('keyword');
        } else {
            $data['keyword'] = null;
        }
        
        $data['penduduk'] = $this->Model_penduduk->getAllpenduduk($data['keyword']);
       
        $this->load->view('templates/header.php', $data);
        $this->load->view('penduduk/index.php', $data);
        $this->load->view('templates/footer.php');
    }
    
    public function tambah()
    {
        $data['bansos'] = $this->Model_bansos->getAllBansos();
        $this->form_validation->set_rules('nik', 'Nik', 'trim|required|numeric');
        $this->form_validation->set_rules('nama', 'Nama', 'trim|required');
        $this->form_validation->set_rules('bansos', 'Bansos', 'trim|required');
        $this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email');
        $this->form_validation->set_rules('hp', 'Hp', 'trim|required|numeric');
        $this->form_validation->set_rules('alamat', 'Alamat', 'trim|required');


        if($this->form_validation->run() == false ) {
            $data['title'] = 'Tambah penduduk';

            $this->load->view('templates/header.php', $data);
            $this->load->view('penduduk/tambah.php', $data);
            $this->load->view('templates/footer.php');
        } else {
            $this->Model_penduduk->Tambahpenduduk();
            redirect('penduduk');
        }
        
    }

    public function ubah($id)
    {
        $data['penduduk'] = $this->Model_penduduk->getpendudukById($id);
        $data['bansos'] = $this->Model_bansos->getAllBansos();
        $this->form_validation->set_rules('nik', 'Nik', 'trim|required|numeric');
        $this->form_validation->set_rules('nama', 'Nama', 'trim|required');
        $this->form_validation->set_rules('bansos', 'Bansos', 'trim|required');
        $this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email');
        $this->form_validation->set_rules('hp', 'Hp', 'trim|required|numeric');
        $this->form_validation->set_rules('alamat', 'Alamat', 'trim|required');


        if($this->form_validation->run() == false ) {
            $data['title'] = 'Ubah penduduk';

            $this->load->view('templates/header.php', $data);
            $this->load->view('penduduk/ubah.php', $data);
            $this->load->view('templates/footer.php');
        } else {
            $this->Model_penduduk->Ubahpenduduk();
            $old_image = $data['penduduk']['foto'];
            unlink(FCPATH . 'assets/foto/' . $old_image);
            $this->session->set_flashdata('flash', 'Diubahkan');
            redirect('penduduk');
        }
        
    }

    public function detail($id)
    {
        $data['penduduk'] = $this->Model_penduduk->getpendudukById($id);
       
        $data['title'] = 'Detail penduduk';
        $this->load->view('templates/header.php', $data);
        $this->load->view('penduduk/detail.php', $data);
        $this->load->view('templates/footer.php');

    }

    public function hapus($id)
    {
        $data['penduduk'] = $this->Model_penduduk->getpendudukById($id);
        $old_image = $data['penduduk']['foto'];
        unlink(FCPATH . 'assets/foto/' . $old_image);
        $this->Model_penduduk->hapuspenduduk($id);
        $this->session->set_flashdata('flash', 'Dihapus');
        redirect('penduduk');
    }
}