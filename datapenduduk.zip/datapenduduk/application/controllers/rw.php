<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Rw extends CI_Controller {

    public function __construct()
	{
		parent::__construct();
		$this->load->library('form_validation');
        $this->load->model('Model_rw');
        if(!$this->session->userdata('username')) {
            redirect('auth');
        }
    }

    public function index()
    {
        $data['title'] = 'Rw';

        $data['rw'] = $this->Model_rw->getAllRw();
        if( $this->input->post('keyword') ) {
            $data['rw'] = $this->Model_rw->Carirw();
        }
        $this->load->view('templates/header.php', $data);
        $this->load->view('rw/index.php', $data);
        $this->load->view('templates/footer.php');
    }

    public function tambah()
    {
        $this->form_validation->set_rules('rw', 'Rw', 'trim|required');

        if($this->form_validation->run() == false ) {
            $data['title'] = 'Tambah Rw';

            $this->load->view('templates/header.php', $data);
            $this->load->view('rw/tambah.php', $data);
            $this->load->view('templates/footer.php');
        } else {
            $this->Model_rw->Tambahrw();
            $this->session->set_flashdata('flash', 'Ditambahkan');
            redirect('rw');
        }
        
    }

    public function ubah($id)
    {
        $this->form_validation->set_rules('rw', 'Rw', 'trim|required');
        $data['rw'] = $this->Model_rw->getrwById($id);

        if($this->form_validation->run() == false ) {
            $data['title'] = 'Ubah Rw';

            $this->load->view('templates/header.php', $data);
            $this->load->view('rw/ubah.php', $data);
            $this->load->view('templates/footer.php');
        } else {
            $this->Model_rw->UbahRw();
            $this->session->set_flashdata('flash', 'Diubah');
            redirect('rw');
        }
        
    }

    public function hapus($id)
    {
        $this->Model_rw->hapusrw($id);
        $this->session->set_flashdata('flash', 'Dihapus');
        redirect('rw');
    }
}