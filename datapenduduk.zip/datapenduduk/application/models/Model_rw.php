<?php
class Model_rw extends CI_Model 
{
    public function getAllRw()
    {
        return $query = $this->db->get('rw')->result_array();
    }

    public function Tambahrw()
    {
        $data = [
            "rw" => $this->input->post('rw', true)
        ];

        $this->db->insert('rw', $data);
    }

    public function Ubahrw()
    {
        $data = [
            "rw" => $this->input->post('rw', true)
        ];

        $this->db->where('id', $this->input->post('id'));
        $this->db->update('rw', $data);
    }

    public function hapusRw($id)       
    {
        $this->db->where('id', $id);
        $this->db->delete('rw');
    }

    public function getRwById($id)
    {
        return $this->db->get_where('rw', ['id' => $id])->row_array();
    }

    public function Carirw()
    {
        $keyword = $this->input->post('keyword', true);
        $this->db->like('rw', $keyword);
        return $this->db->get('rw')->result_array();
    }
}

?>