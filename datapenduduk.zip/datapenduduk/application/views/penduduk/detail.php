<div class="container">
    <div class="card" style="width: 18rem;">
    <img src="<?= base_url('assets/foto/') . $penduduk['foto']; ?>" class="card-img-top" alt="...">
        <div class="card-body">
            <h5 class="card-title"><?= $penduduk['nik']; ?></h5>
            <p class="card-text"><?= $penduduk['nama']; ?></p>
        </div>
        <ul class="list-group list-group-flush">
            <li class="list-group-item"><?= $penduduk['bansos']; ?></li>
            <li class="list-group-item"><?= $penduduk['email']; ?></li>
            <li class="list-group-item"><?= $penduduk['hp']; ?></li>
            <li class="list-group-item"><?= $penduduk['alamat']; ?></li>
        </ul>
        <div class="card-body">
            <a href="<?= base_url('penduduk'); ?>" class="btn btn-primary">Kembali</a>
        </div>
    </div>
</div>

