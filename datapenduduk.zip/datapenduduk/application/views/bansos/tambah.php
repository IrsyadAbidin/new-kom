<div class="container">
    <form action="" method="post">
        <legend>Tambah Data Bansos</legend>
        <div class="mb-3">
            <label for="jurusanbansos" class="form-label">Nama Bansos</label>
            <input type="text" class="form-control" id="bansos" name="bansos" style="width : 300px;">
            <div class="form-text text-danger"><?= form_error('bansos'); ?></div>
        </div>
        <input type="submit" value="submit" class="btn btn-primary"></input>
    </form>
</div>