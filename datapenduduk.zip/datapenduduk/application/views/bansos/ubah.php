<div class="container">
    <form action="" method="post">
        <legend>Ubah Data Bansos</legend>
        <div class="mb-3">
            <input type="hidden" name="id" value="<?= $bansos['id']; ?>">
            <label for="bansos" class="form-label">Nama Bansos</label>
            <input type="text" class="form-control" id="bansos" name="bansos" value="<?= $bansos['bansos']; ?>" style="width : 300px;">
            <div class="form-text text-danger"><?= form_error('bansos'); ?></div>
        </div>
        <input type="submit" name="ubah" value="ubah" class="btn btn-primary"></input>
    </form>
</div>