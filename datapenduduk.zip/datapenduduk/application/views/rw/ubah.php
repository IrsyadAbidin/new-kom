<div class="container">
    <form action="" method="post">
        <legend>Ubah Data Rw</legend>
        <div class="mb-3">
            <input type="hidden" name="id" value="<?= $rw['id']; ?>">
            <label for="rw" class="form-label">Nama Rw</label>
            <input type="text" class="form-control" id="rw" name="rw" value="<?= $rw['rw']; ?>" style="width : 300px;">
            <div class="form-text text-danger"><?= form_error('rw'); ?></div>
        </div>
        <input type="submit" name="ubah" value="ubah" class="btn btn-primary"></input>
    </form>
</div>