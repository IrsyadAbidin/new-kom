<div class="container">
    <h3>SELAMAT DATANG ADMIN SEMOGA LANCAR SEMUA AKTIVITASNYA</h3>
    <h2> Keuntungan Aplikasi WEB Data Penduduk :</h2>
    <h1>1.Mudah Diakses</h1>
    <p>Aplikasi berbasis web sangat mudah untuk diakses karena tidak perlu instal aplikasi seperti di gawai untuk membukanya. Cukup membutuhkan jaringan internet, Anda dapat mengakses aplikasi melalui browser.</p>
    <h1>2.Hemat Penyimpanan</h1>
    <p>Aplikasi website tidak menghabiskan penyimpanan pada perangkat Anda karena langsung terhubung ke penyimpanan cloud. Maksud dari penyimpanan cloud adalah media penyimpanan file berbasis daring atau digital yang mengandalkan koneksi internet untuk akses data. Hal itu, tentu memudahkan staf karena tidak perlu lagi menyimpan data secara manual, semua akan tersimpan dalam sistem.</p>
    <h1>3.Diakses di Berbagai Perangkat</h1>
    <p>Tidak terbatas pada PC saja, aplikasi web dapat diakses melalui gawai ataupun tablet yang memiliki koneksi internet. Sehingga memudahkan pengguna yang memiliki mobilitas tinggi.</p>
    <h1>
    4.Responsive
    </h1>
    <p>Maksud dari responsive disini adalah tampilan dalam aplikasi akan menyesuaikan dengan perangkat. Jadi, tampilan aplikasi tidak berubah meskipun perangkatnya berbeda.</p>
    <h1>5.Murah dan Powerful</h1>
    <p>
    Saat menggunakan aplikasi dan perangkat lunak berbasis dekstop, maka perlu mempertimbangkan dari segi kekuatan mesin yang digunakan. Terkadang pembaruan aplikasi membutuhkan kemampuan pada hardware. 

Tentu saja hal ini membutuhkan biaya yang tidak sedikit. Berbanding terbalik kita menggunakan aplikasi website yang dapat diakses di berbagai perangkat. Hal tersebut terjadi karena aplikasi berbasis web lebih ringan dibandingkan dengan aplikasi desktop.
    </p>
</div>